<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Bienvenue!</h1>
    <h2>Pour commencer VOUS DEVEZ AVOIR FAIT LE PREMIER TUTO</h2>
    <h3>
        Alors, normalement la page "home" est pré-installée
        <br>
        Pour installer une nouvelle page, allez sur CETTE page : <a href="./lwp-admin/modifyPage.php">Sur la droite vous
            <br>
            devrez voir un champ de texte et un bouton valider, mettez le nom de votre page dans le champ de texte
            renterez le nom de la page
        </a>

        <h2>ATTENTION les nom de pages ont des contraintes, sinon vous pourriez corrompre votre LWPS</h2>
        <br>
        Les characters suivant <,>, :, “, /, \, |, ?, * sont interdits ET SURTOUT PAS D'ESPACES À LA FIN
            <br>
            Maintenant, voyons comment accéder à cette page très simple, 1: allez sur cette page : <span class="adrs">
            </span>home/ puis cliquez sur le grand crayon, et vous y voilà OU <span class="adrs"></span>home/modify.php
            <br>
            pour vos propres page, c'est simple, remplacer "home" par le nom de la page!
            <br>
            1 Chose pas dite dans le tuto : pour déplacer un object :
            <br>
            Vous avez un bouton "modifier la place des elements"
            <br>
            vous cliquerez dessus, vous aurez quelque chose à peu près comme cela :
            <br>
            [1,2,3,4],
            <br>
            Aussi si vous fermez le menu vous pourrez voir des écris à peu près comme cela : Element Numéro : X,
            <br>
            (le X représente un chiffre)
            <br>
            en fait c'est son ID si vous préférer.
            <br>
            maintenant décodons ceci :
            <br>
            [1->C'est l'element numéro 1, ou plus exactement ou c'est marqué Element Numéro : 1
            <br>
            imaginons :
            <br>
            Menu (1)
            <br>
            Séparation (2)
            <br>
            Formulaire de connexion (3)
            <br>
            Footer (bas de page) (4)
            <br>
            si nous voulons que cela fasse comme cela :
            <br>
            <br>
            Menu (1)
            <br>
            Formulaire de connexion (3)
            <br>
            Séparation (2)
            <br>
            Footer (bas de page) (4)
            <br><br>
            Il suffi de faire comme cela :
            <br>
            [1,2,3,4] -> [1,3,2,4]
            <br>
            Simple, non?
            <br>
            TOUJOURS cliquer sur valider
            <br>
            <br>
            -------------------------------------------
            <br>
            <br>
            Plug-In
            <br>
            <br>
            1: installer un plug-in, est deja fournit dans la page d’accueil,
            <br>
            2: Il y as deux types de plu-ins.
            <br>
            1: ceux de page, il ajoute juste une page, on peut la retrouver dans lwp-admin/panel.php
            <br>
            Petite desc des plug-ins les plus simple :
            <br>
            LWPS Recovery (ou réparateur de pages),
            <br>
            imaginons que vous vous tromper dans [1,2,3,4] -> [1,3,2,4]x et que un character non-intentionnel!
            <br>
            Installez cette extension et allez sur la page de cette extension, rentrez le nom de votre page et voilà
            <br>
            SimpleText:
            <br>
            Rajoute du texte
            <br>
            <br>
            <br>
            MERCI D'AVOIR SUIVIT CE TUTO!!!!
    </h3>
    <script>
    document.querySelectorAll(".adrs").forEach((domElementSpanAddress) => {
        domElementSpanAddress.innerHTML = location.href.split("tuto.php")[0];
    })
    </script>
</body>

</html>