<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {

if (!empty($_GET["type"])) {
    if ($_GET["type"]=="submit") {
        $JSON = json_decode(file_get_contents("../lwp-client/pages.json"));
        if (!empty($JSON->{$_GET["page"]})) {
            $JSONResp = $JSON->{$_GET["page"]};
            $JSON->{$_POST["NewName"]} = $JSONResp;
            $JSON->{$_POST["NewName"]}->name = $_POST["NewName"];
            unset($JSON->{$_GET["page"]});
            file_put_contents("../lwp-client/pages.json", json_encode($JSON));
            echo "All OK";
        } else {
            echo "Page non-valide!";
        }
    }
}
} else {
    header("Location: ../lwp-error/start.php");
  }
  } else {
    header("Location: ../lwp-error/start.php");
  }
?>
<!DOCTYPE html>
<html>

<head>
    <title>Panel</title>
    <style>
    /* Style général */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    /* En-tête */
    header {
        background-color: #222;
        color: #fff;
        display: flex;
        justify-content: space-between;
        padding: 10px;
        position: relative;
    }

    header h1 {
        margin: 0;
        font-size: 2em;
        font-weight: bold;
        text-transform: uppercase;
    }

    header a {
        color: #fff;
        text-decoration: none;
    }

    /* Menu latéral */
    nav {
        background-color: #444;
        color: #fff;
        height: calc(100% - 50px);
        overflow: auto;
        padding: 10px;
        position: absolute;
        top: 50px;
        bottom: 0;
        left: 0;
        width: 200px;
    }

    nav ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    nav li {
        margin-bottom: 10px;
    }

    nav a {
        color: #fff;
        text-decoration: none;
        display: block;
        padding: 10px;
    }

    nav a:hover {
        background-color: #666;
    }

    /* Contenu principal */
    main {
        padding: 10px;
        margin: 50px 0 0 300px;
    }

    /* Formulaire de configuration */
    .config-form {
        background-color: #eee;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin: 10px 0;
        padding: 20px;
    }

    .config-form label {
        display: block;
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .config-form input[type="text"] {
        width: 100%;
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-bottom: 20px;
    }

    .config-form button {
        background-color: #0073aa;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1.2em;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .config-form button:hover {
        background-color: #00608d;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 20px;
        flex-wrap: wrap;
    }

    label {
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    input[type="text"] {
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    input[type="submit"] {
        background-color: #8b0000;
        border: none;
        color: #fff;
        cursor: pointer;
        font-family: serif;
        font-size: 1.2em;
        padding: 10px 20px;
        text-transform: uppercase;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #b22222;
    }


    #install-button {
        font-family: arial;
        font-size: 14pt;
        letter-spacing: 1px;
        padding-top: 7px;
        padding-bottom: 7px;
        padding-left: 12px;
        padding-right: 12px;
        color: #19ab20;
        text-decoration: none;
        border-style: solid;
        border-width: 1.5px;
        border-radius: 6px;
    }

    html {
        height: 100%;
    }

    body {
        font-size: 16px;
        font-family: "proxima-nova", "Proxima Nova";
        text-align: center;
        color: #999999;
        background-color: #ccc;
        height: 100%;
    }

    body::after {
        content: '';
        display: inline-block;
        height: 100%;
        vertical-align: middle;
    }

    * {
        -moz-box-sizing: border-box;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    .button {
        border-radius: 2px;
        border-bottom: 3px solid rgba(0, 0, 0, 0.2);
        background: #22c6b8;
        display: inline-block;
        text-align: center;
        text-transform: uppercase;
        margin: 0 5px 0 0;
        position: relative;
    }

    .button:hover {
        border-bottom: 5px solid rgba(0, 0, 0, 0.2);
        position: relative;
        top: -2px;
        background: #0fbbad;
    }

    .button:active {
        border-bottom: 3px solid rgba(0, 0, 0, 0.2);
        position: relative;
        top: 0px;
    }

    .button a {
        color: #fff;
        font-weight: 500;
        text-decoration: none;
        display: inline-block;
        padding: 10px 18px;
        width: 170px;
        position: relative;
        z-index: 3;
    }

    .button i {
        position: relative;
        top: 2px;
        display: inline-block;
        margin: 0 10px 0 0;
    }

    .buttonACT {
        position: absolute;
        width: auto;
        background: rgba(0, 0, 0, 0.15);
        top: 0;
        left: 0;
        right: 170px;
        bottom: -3px;
        content: " ";
        z-index: 2;
        animation-delay: 2s;
        border-radius: 2px 0 0 2px;
    }

    .button:hover::before {
        bottom: -5px;
    }

    @keyframes slide {
        0% {
            right: 170px;
        }

        5% {
            right: 140px;
        }

        15% {
            right: 140px;
        }

        20% {
            right: 110px;
        }

        30% {
            right: 110px;
        }

        35% {
            right: 80px;
        }

        45% {
            right: 80px;
        }

        50% {
            right: 50px;
        }

        60% {
            right: 50px;
        }

        65% {
            right: 0px;
            border-radius: 2px 0 0 2px;
        }

        75% {
            right: 0px;
            opacity: 1.0;
            border-radius: 2px;
        }

        85% {
            right: 0px;
            opacity: 0;
        }

        100% {
            right: 0px;
            opacity: 0;
        }
    }
    </style>
</head>

<body>
    <header>
        <h1>Modifier le site : <?php echo json_decode(file_get_contents("../lwp-client/infos.json"))->name; ?></h1> <a
            href="./index.php">Panel les
            pages</a>
    </header>
    <nav>
        <ul>
            <li><a href="../lwp-error/start.php">Modifier le mot de passe</a></li>
            <li>
                <a href="./panel.php"> Panel</a>
            </li>
        </ul>
    </nav>
    <main>
        <!-- le contenu du panel -->
        <h3>List des plugins :</h3>
        <ul>
            <?php
            $JSON = json_decode(file_get_contents("https://loines.ch/api/lwps/plugin.json"), true);
            foreach ($JSON as $key => $value) {
                echo "<li>
                <h3>Nom : ".$value["Name"]."</h3>
                <script type=\"text/javascript\" src=\"//use.typekit.net/uvs8amk.js\"></script>
<script type=\"text/javascript\">try{Typekit.load();}catch(e){}</script>

<div class=\"button\" id='".$key."'><a href=\"#\"><i class=\"ss-icon\"></i>Installer</a><div class='buttonACT'></div></div>
                </li>";
            }
            ?>
        </ul>
    </main>
    <footer>
    </footer>
    <script>
    let xlm2 = new XMLHttpRequest();
    xlm2.responseType = "json";
    xlm2.open("GET", "../lwp-client/pages.json");
    xlm2.send();
    xlm2.onload = function() {
        let object = xlm2.response;
        for (const key in object) {
            if (Object.hasOwnProperty.call(object, key)) {
                const element = object[key];
                document.querySelector("nav > ul").innerHTML += `
          <li class="Menu-Item"><a href='../lwp-admin/modifyPage.php?type=form&page=${key}'>${element.name} (accès : ${element.path}) ✏️</a></li>
          `;
            }
        }
    };
    document.querySelectorAll(".button").forEach((element) => {
        element.addEventListener("click", () => {
            element.querySelector(".buttonACT").style.animation = "slide 4s linear forwards";
            const xml = new XMLHttpRequest();
            xml.open("POST", "plug-inst.php?name=" + element.id + "");
            xml.onload = function() {
                element.querySelector("a").innerHTML = `
                <i class="ss-icon"></i>
                Installé
                `;
            }
            xml.send();
        });
    })
    </script>
</body>

</html>