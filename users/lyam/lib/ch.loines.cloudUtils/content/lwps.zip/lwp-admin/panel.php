<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {

if (!empty($_GET["type"])) {
    if ($_GET["type"]=="submit") {
        $JSON = json_decode(file_get_contents("../lwp-client/pages.json"));
        if (!empty($JSON->{$_GET["page"]})) {
            $JSONResp = $JSON->{$_GET["page"]};
            $JSON->{$_POST["NewName"]} = $JSONResp;
            $JSON->{$_POST["NewName"]}->name = $_POST["NewName"];
            unset($JSON->{$_GET["page"]});
            file_put_contents("../lwp-client/pages.json", json_encode($JSON));
            echo "All OK";
        } else {
            echo "Page non-valide!";
        }
    }
}
} else {
    header("Location: ../lwp-error/start.php");
  }
  } else {
    header("Location: ../lwp-error/start.php");
  }
?>
<!DOCTYPE html>
<html>

<head>
    <title>Panel</title>
    <style>
    /* Style général */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    /* En-tête */
    header {
        background-color: #222;
        color: #fff;
        display: flex;
        justify-content: space-between;
        padding: 10px;
        position: relative;
    }

    header h1 {
        margin: 0;
        font-size: 2em;
        font-weight: bold;
        text-transform: uppercase;
    }

    header a {
        color: #fff;
        text-decoration: none;
    }

    /* Menu latéral */
    nav {
        background-color: #444;
        color: #fff;
        height: calc(100% - 50px);
        overflow: auto;
        padding: 10px;
        position: absolute;
        top: 50px;
        bottom: 0;
        left: 0;
        width: 200px;
    }

    nav ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    nav li {
        margin-bottom: 10px;
    }

    nav a {
        color: #fff;
        text-decoration: none;
        display: block;
        padding: 10px;
    }

    nav a:hover {
        background-color: #666;
    }

    /* Contenu principal */
    main {
        padding: 10px;
        margin: 50px 0 0 300px;
    }

    /* Formulaire de configuration */
    .config-form {
        background-color: #eee;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin: 10px 0;
        padding: 20px;
    }

    .config-form label {
        display: block;
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .config-form input[type="text"] {
        width: 100%;
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-bottom: 20px;
    }

    .config-form button {
        background-color: #0073aa;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1.2em;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .config-form button:hover {
        background-color: #00608d;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 20px;
        flex-wrap: wrap;
    }

    label {
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    input[type="text"] {
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    input[type="submit"] {
        background-color: #8b0000;
        border: none;
        color: #fff;
        cursor: pointer;
        font-family: serif;
        font-size: 1.2em;
        padding: 10px 20px;
        text-transform: uppercase;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #b22222;
    }
    </style>
</head>

<body>
    <header>
        <h1>Modifier le site : <?php echo json_decode(file_get_contents("../lwp-client/infos.json"))->name; ?></h1> <a
            href="./index.php">Panel les
            pages</a>
    </header>
    <nav>
        <ul>
            <li><a href="../lwp-error/start.php">Modifier le mot de passe</a></li>
            <li>
                <a href="./plugin.php">⭐🆕⭐ Plugins</a>
            </li>
        </ul>
    </nav>
    <main>
        <!-- le contenu du panel -->
        <h3>List des plugins :</h3>
        <ul>
            <?php
            $JSON = json_decode(file_get_contents("../lwp-client/plugins.json"), true);
            foreach ($JSON as $key => $value) {
                echo "<li>
                <h3>Nom : ".$value["Name"]."</h3>
                <a href='pluginM.php?name=$key'><h4>Accéder à  la page du plug-in</h4></a>
                </li>";
            }
            ?>
        </ul>
        <a href="./plugin.php">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="black" class="bi bi-plus-circle"
                viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
            </svg>
        </a>
    </main>
    <footer>
    </footer>
    <script>
    let xlm2 = new XMLHttpRequest();
    xlm2.responseType = "json";
    xlm2.open("GET", "../lwp-client/pages.json");
    xlm2.send();
    xlm2.onload = function() {
        let object = xlm2.response;
        for (const key in object) {
            if (Object.hasOwnProperty.call(object, key)) {
                const element = object[key];
                document.querySelector("nav > ul").innerHTML += `
          <li class="Menu-Item"><a href='../lwp-admin/modifyPage.php?type=form&page=${key}'>${element.name} (accès : ${element.path}) ✏️</a></li>
          `;
            }
        }
    };
    </script>
</body>

</html>