
<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {

if (!empty($_GET["type"])) {
    if ($_GET["type"]=="submit") {
        $JSON = json_decode(file_get_contents("../lwp-client/pages.json"));
        if (!empty($JSON->{$_GET["page"]})) {
            $JSONResp = $JSON->{$_GET["page"]};
            $JSON->{$_POST["NewName"]} = $JSONResp;
            $JSON->{$_POST["NewName"]}->name = $_POST["NewName"];
            unset($JSON->{$_GET["page"]});
            file_put_contents("../lwp-client/pages.json", json_encode($JSON));
            echo "All OK";
        } else {
            echo "Page non-valide!";
        }
    }
}
} else {
    exit;
  }
  } else {
    exit;
  }
?>
<h1>Bienvenu sur mon plug-in LWPS (SimpleText Plug-In), <a href='https://www.youtube.com/watch?v=dQw4w9WgXcQ'>Voir mes autres plug-in</a></h1>