<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {

if (!empty($_GET["type"])) {
    if ($_GET["type"]=="submit") {
        $JSON = json_decode(file_get_contents("../lwp-client/pages.json"));
        if (!empty($JSON->{$_GET["page"]})) {
            $JSONResp = $JSON->{$_GET["page"]};
            $JSON->{$_POST["NewName"]} = $JSONResp;
            $JSON->{$_POST["NewName"]}->name = $_POST["NewName"];
            unset($JSON->{$_GET["page"]});
            file_put_contents("../lwp-client/pages.json", json_encode($JSON));
            echo "All OK";
        } else {
            echo "Page non-valide!";
        }
    }
}
} else {
    header("Location: ../lwp-error/start.php");
  }
  } else {
    header("Location: ../lwp-error/start.php");
  }
?>
<!DOCTYPE html>
<html>

<head>
    <title>Panel</title>
    <style>
    /* Style général */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    /* En-tête */
    header {
        background-color: #222;
        color: #fff;
        display: flex;
        justify-content: space-between;
        padding: 10px;
        position: relative;
    }

    header h1 {
        margin: 0;
        font-size: 2em;
        font-weight: bold;
        text-transform: uppercase;
    }

    header a {
        color: #fff;
        text-decoration: none;
    }

    /* Menu latéral */
    nav {
        background-color: #444;
        color: #fff;
        height: calc(100% - 50px);
        overflow: auto;
        padding: 10px;
        position: absolute;
        top: 50px;
        bottom: 0;
        left: 0;
        width: 200px;
    }

    nav ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    nav li {
        margin-bottom: 10px;
    }

    nav a {
        color: #fff;
        text-decoration: none;
        display: block;
        padding: 10px;
    }

    nav a:hover {
        background-color: #666;
    }

    /* Contenu principal */
    main {
        padding: 10px;
        margin: 50px 0 0 300px;
    }

    /* Formulaire de configuration */
    .config-form {
        background-color: #eee;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin: 10px 0;
        padding: 20px;
    }

    .config-form label {
        display: block;
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .config-form input[type="text"] {
        width: 100%;
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-bottom: 20px;
    }

    .config-form button {
        background-color: #0073aa;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1.2em;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .config-form button:hover {
        background-color: #00608d;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 20px;
        flex-wrap: wrap;
    }

    label {
        font-size: 1.2em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    input[type="text"] {
        padding: 10px;
        font-size: 1.2em;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    input[type="submit"] {
        background-color: #8b0000;
        border: none;
        color: #fff;
        cursor: pointer;
        font-family: serif;
        font-size: 1.2em;
        padding: 10px 20px;
        text-transform: uppercase;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #b22222;
    }
    </style>
</head>

<body>
    <header>
        <h1>Modifier la page : <?php if (!empty($_GET["page"])) {
            echo $_GET["page"];
        } ?></h1> <a href="./panel.php">Panel du site</a>
    </header>
    <nav>
        <ul>
            <li><a href="../lwp-error/start.php">Modifier le mot de passe</a></li>
            <li>
                <form action="../createPage.php" method="post">
                    Créer une page (Nom)
                    <input type="text" name="Name">
                    <input type="submit" value="Valider">
                </form>
                <form action="./webName.php" method="post">
                    Modifier le nom de votre site web
                    <input type="text" name="Name" value="MyWebSite">
                    <input type="submit" value="Valider">
                </form>
            </li>
        </ul>
    </nav>
    <main>
        <form action="./modifyPage.php?type=submit&page=<?php  if (!empty($_GET["page"])) {
            echo $_GET["page"];
        } ?>" method="post">
            <input type="text" name="NewName" id="Nouveau Nom">
            <input type="submit" value="Changer">
        </form>
        <!-- le contenu du panel -->
        <a href="./panel.php"><button>PANEL POUR LES PLUGINS</button></a>
    </main>
    <footer>
    </footer>
    <script>
    let xlm2 = new XMLHttpRequest();
    xlm2.responseType = "json";
    xlm2.open("GET", "../lwp-client/pages.json");
    xlm2.send();
    xlm2.onload = function() {
        let object = xlm2.response;
        for (const key in object) {
            if (Object.hasOwnProperty.call(object, key)) {
                const element = object[key];
                document.querySelector("nav > ul").innerHTML += `
          <li class="Menu-Item"><a href='../lwp-admin/modifyPage.php?type=form&page=${key}'>${element.name} (accès : ${element.path}) ✏️</a></li>
          `;
            }
        }
    };
    </script>
</body>

</html>