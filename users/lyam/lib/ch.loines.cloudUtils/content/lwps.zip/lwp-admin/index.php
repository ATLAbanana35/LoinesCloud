<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"]==$CODE) {
        header("Location: modifyPage.php");
    } else {
    header("Location: ../lwp-error/start.php");
}
} else {
header("Location: ../lwp-error/start.php");
    }
?>
