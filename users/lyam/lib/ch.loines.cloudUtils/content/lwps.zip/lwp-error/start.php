
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Installing</title>
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <main>
        <h1>!!! UNE FOIS CONNECTEZ (OUVREZ CETTE PAGE POUR LA PREMIÈRE FOIS) METTEZ UN AUTRE MOT DE PASSE (mot de passe
            par déf : 1234)!!!!!</h1>
        <?php

                if (!empty($_POST["password"])) {
                    setcookie("LWPS_PASSWORD", $_POST["password"], time()+2300000, "/", $_SERVER["SERVER_NAME"]);
                }
        include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {
        echo "C.O.D.E OK!";
        if (!empty($_POST["password2"])) {
            rename("../lwp-serveur/".$CODE.".json", "../lwp-serveur/".$_POST["password2"].".json");
            setcookie("LWPS_PASSWORD", $_POST["password2"], time()+2300000, "/", $_SERVER["SERVER_NAME"]);
            file_put_contents("../lwp-serveur/password.php", '
            <?php
            $CODE="'.$_POST["password2"].'"
            ?>
        ');
        echo "MDP CHANGÉ!";
        }
        } else {
        echo "WRONG CODE!";
        }
        } else {
        setcookie("LWPS_PASSWORD", "1234", time()+2300000, "/", $_SERVER["SERVER_NAME"]);
        }
        ?>
        <form method="post" action="./start.php">
            <input name="password" type="password" placeholder="Mot de passe"></input>
            <input type="submit" value="Se Connecter"></input>
            <br>
            ^
            <br>
            |
            <h2>(Nouveau Mot De Passe Mettez votre mdp AVANT)</h2>
            <input name="password2" type="password" placeholder="Nouveau Mot de passe"></input>
            <input type="submit" value="Valider"></input>
            <a href="index.php">Retours</a>
        </form>
    </main>
    <style>
    body {
        background: rgb(182, 91, 91);
        font-family: Arial, Helvetica, sans-serif;
    }

    main {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 70%;
        height: 70%;
        background-color: white;
        border: 10px solid black;
        border-radius: 20px;
        box-shadow: inset 0 0 20px 0px;
        overflow: scroll;
    }

    input {
        padding: 10px;
        background-color: salmon;
        color: black;
        border-radius: 20px;
        transition: 0.5s;
    }

    input[type="submit"]:hover {
        letter-spacing: 5px;
    }

    .red {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: red;
    }
    </style>
</body>

</html>
