<?php
    $list = [];
?>