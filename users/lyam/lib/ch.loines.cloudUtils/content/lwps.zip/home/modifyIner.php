<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {

include_once("../lwp-libs/php.php");
include_once("./content/list.php"); 
foreach ($list as $i) {
  echo "<hr><span>".file_get_contents("content/".$i.".txt")."</span><h3>Element Numéro : $i</h3><a style='color: black;' href='delete.php?file=$i'>❌/!\ Cette fonction ne marche pas bien! Utilisez Modifier la place des elements à la place</a>";
}
} else {
    header("Location: ../lwp-error/start.php");
  }
} else {
    header("Location: ../lwp-error/start.php");
  }
?>