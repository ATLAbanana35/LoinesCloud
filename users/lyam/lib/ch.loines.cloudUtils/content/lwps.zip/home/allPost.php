
<h1>All Posts : </h1>
<hr>
<?php
include_once("../lwp-serveur/password.php");
$JSON = json_decode(file_get_contents("../lwp-serveur/" . $CODE . ".json"));
$list = [];
$list2 = [];
foreach ($JSON->posts as $event) {
    array_push($list ,$event->timestamp);
    $list2[$event->timestamp] = $event;
}
for ($i=0; $i < count($list); $i++) { 
    echo "<h1> Nom : ".$list2[$list[$i]]->Name . "</h1>".$list2[$list[$i]]->content . "de : " . $list2[$list[$i]]->creator."<hr>";
}

?>
<style>
body {
    font-family: Arial;
}
</style>
