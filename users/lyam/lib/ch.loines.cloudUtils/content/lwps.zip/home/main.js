
let toggle = false;
document.querySelector(".close").addEventListener("click", () => {
if (!toggle) {
document.querySelector(".GUI_BOX_NewObject").style.top = "-10000px";
document.querySelector(".close").textContent = "open";
toggle = true;
} else {
document.querySelector(".GUI_BOX_NewObject").style.top = "0px";
document.querySelector(".close").textContent = "close";
toggle = false;
}
});
function seeFom(to, name, input) {
document.body.innerHTML += `
<form method="post" action="${to}" class="form">
    ${name} :
    <br>
</form>
`;
let form = document.querySelector(".form");
for (const key in input) {
if (Object.hasOwnProperty.call(input, key)) {
const element = input[key];
let Random = Math.floor(Math.random() * 1000);
form.innerHTML += `
<label for='s${Random}'>${element.label}</label>
<input id='s${Random}' type='${element.type}' name='${key}'></input>
<br>
`;
}
}
form.innerHTML += `
<input type='submit' name='submit' value="Valider"></input>
<br>
`;
}
document.querySelector(".NewObject_menu").addEventListener("click", (e) => {
seeFom("./action.php?type=addMenu", "Menu", {
Name: {
type: "text",
label: "Titre",
},
});
});
document.querySelector(".NewObject_sep").addEventListener("click", (e) => {
seeFom("./action.php?type=addSep", "Séparateur", {
Color: {
type: "color",
label: "Couleur",
},
Width: {
type: "number",
label: "Hauteur (px)",
},
});
});
document
.querySelector(
"body > div.GUI_BOX_NewObject > h3.GUI_BUTTON.NewObject_newPost"
)
.addEventListener("click", (e) => {
seeFom("./action.php?type=addAct_NewPosts", "Nouveaux Posts", {
NumberOfPosts: {
type: "number",
label: "Nombre de posts",
},
});
});
document
.querySelector(".NewObject_FoprmConnect")
.addEventListener("click", (e) => {
seeFom("./action.php?type=addForm_Connect", "Formulaire de connexion", {
Slogan: {
type: "text",
label: "Slogan (genre Bienvenue!)",
},
Style: {
type: "text",
label: "Futuriste (F), Ancien, (A), Basé sur une couleur : (C)",
},
Color: {
type: "color",
label: "(UNIQUEMENT SI C)",
},
});
});
document
.querySelector(".NewObject_addAdderForm")
.addEventListener("click", (e) => {
seeFom("./action.php?type=addPostAdder", "Formulaire d'ajout de post", {
Slogan: {
type: "text",
label: "Slogan (genre Merci de poster des posts corrects!)",
},
Style: {
type: "text",
label: "Futuriste (F), Ancien, (A), Basé sur une couleur : (C)",
},
Color: {
type: "color",
label: "couleur de fond (UNIQUEMENT SI C)",
},
ColorP: {
type: "color",
label: "Couleur du texte",
},
});
});
document.querySelector(".NewObject_image").addEventListener("click", (e) => {
seeFom("./action.php?type=addImg", "Image", {
Source: {
type: "url",
label: "Source (genre https://example.com/img.png)",
},
Width: {
type: "number",
label: "Taille (En % de l'écran horizontal)",
},
});
});
document.querySelector(".NewObject_link").addEventListener("click", (e) => {
seeFom("./action.php?type=addLink", "Image", {
Lien: {
type: "url",
label: "Lien (genre https://example.com/mapage.html)",
},
Texte: {
type: "texte",
label: "Texte du lien",
},
});
});
document.querySelector(".NewObject_footer").addEventListener("click", (e) => {
seeFom("./action.php?type=addFooter", "Footer (Bas De Page)", {
Dev: {
type: "text",
label: "Créateur",
},
Color: {
type: "color",
label: "fond",
},
ColorP: {
type: "color",
label: "Couleur de texte",
},
Name: {
type: "text",
label: "Nom du site web",
},
});
});
document.querySelector(".NewObject_AllPosts").addEventListener("click", (e) => {
seeFom("./action.php?type=allPosts", "Rien a mettre", {});
});
document.querySelector(".MODIFY_PLACE").addEventListener("click", () => {
document.body.innerHTML += `
<form method="post" action="rename.php" class="form">
    <h3>Modifie la place des elements (par default: 0,1,2,...) : </h3>
    <input name="elements" value="${
      document.querySelector(" .UUID_692ed7b9-3c1e-4db4-8fb6-2a77f7c1c490") .innerHTML }"></input>
    <input type="submit"></input>
</form>
`;
});

