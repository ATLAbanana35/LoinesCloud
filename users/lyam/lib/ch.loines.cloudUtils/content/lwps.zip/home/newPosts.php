
<h1>New Posts : </h1>
<hr>
<?php
include_once("../lwp-serveur/password.php");
$JSON = json_decode(file_get_contents("../lwp-serveur/" . $CODE . ".json"));
$list = [];
$list2 = [];
foreach ($JSON->posts as $event) {
    array_push($list ,$event->timestamp);
    $list2[$event->timestamp] = $event;
}
for ($i=0; $i < (int) $_GET["number"]; $i++) { 
    echo "<post>"."<h1>Nom: ".$list2[max($list)]->Name . "</h1>".$list2[max($list)]->content . "<h4>De : ".$list2[max($list)]->creator."</h4></post> <br><hr>";
    unset($list[array_search(max($list), $list)]);
}

?>
<style>
body {
    font-family: Arial;
}
</style>
