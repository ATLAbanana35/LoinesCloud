<?php
header("Location: lwp-error/know.php");
?>
