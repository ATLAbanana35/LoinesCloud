
<?php
include_once("./password.php");
if (!empty($_POST["Content"]) && !empty($_POST["Name"])) {
    $JSON = json_decode(file_get_contents($CODE.".json"));
    if (!empty($JSON->users->{$_COOKIE["USER"]})) {
        if (hash_equals($JSON->users->{$_COOKIE["USER"]}->MDP, hash("md5",$_COOKIE["PASSWORD"]))) {
            $rand = rand();
            $JSON->posts->{$rand} = new stdClass;
            $JSON->posts->{$rand}->Name = $_POST["Name"];
            $JSON->posts->{$rand}->content = $_POST["Content"];
            $JSON->posts->{$rand}->creator = $_COOKIE["USER"];
            $JSON->posts->{$rand}->timestamp = time();
            array_push($JSON->users->{$_COOKIE["USER"]}->posts, $rand);
            file_put_contents($CODE.".json", json_encode($JSON));
        header("Location: ../success.php");
    } else {
            header("Location: ../error.php");
        }
    } else {
        header("Location: ../error.php");    
    }
} else {
    header("Location: ../error.php");    
}
?>
