<?php
$code = '$2y$10$o9yYJm9c0Rwo6JK1HUSVsONTo/G6O1/2WRQzXj5UqMFYWnsxMuWOC'
?>