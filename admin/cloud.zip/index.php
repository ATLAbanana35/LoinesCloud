<script>
window.location = "./cloud.php"
</script>
<noscript>
    Please enlabe javascript (Are you in Tor?, OR UNDER WINDOWS 95, if yes I LOVE THE OLD PC (in VM))
</noscript>